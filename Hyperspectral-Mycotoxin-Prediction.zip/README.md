# Hyperspectral Imaging for Mycotoxin Prediction

## Project Overview
This project focuses on processing hyperspectral imaging data to predict mycotoxin levels (DON concentration) in corn samples. The tasks include data preprocessing, visualization, dimensionality reduction, model training, and evaluation using Artificial Neural Networks (ANN).

## Why ANN?  
The ANN model **outperformed other models**, showing the lowest error metrics and highest predictive accuracy.  
**Key reasons for choosing ANN over XGBoost:**  
- ANN captured **complex patterns** in hyperspectral data better than tree-based models.  
- **PCA-based dimensionality reduction** helped optimize ANN performance.  
- ANN had **better generalization**, leading to more accurate predictions.  

## Repository Structure
```
📂 Hyperspectral-Mycotoxin-Prediction
│── 📜 AIML.ipynb            # Jupyter Notebook with full implementation
│── 📜 TASK-ML-INTERN.csv    # Hyperspectral dataset
│── 📜 AIML Model Development.pdf  # Summary report
│── 📜 README.md             # Project overview and instructions
```

## Running the Project
1. Clone the repository:  
   ```bash
   git clone https://github.com/your-username/Hyperspectral-Mycotoxin-Prediction.git
   ```  
2. Navigate to the project folder:  
   ```bash
   cd Hyperspectral-Mycotoxin-Prediction
   ```  
3. Run the Jupyter Notebook:  
   ```bash
   jupyter notebook AIML.ipynb
   ```  

## Contributors  
- **[Your Name]** - Data Processing, Model Development, Evaluation  
